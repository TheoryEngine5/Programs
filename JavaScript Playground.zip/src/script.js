// =================== dev-utils.js ===================
// Fully self-contained JavaScript utility toolkit
// Includes: SmartLogger, retryAsync, DeepUtils, AsyncQueue, validate, memoize, RandomUtils, profile

// ------------------ Smart Logger ------------------
class SmartLogger {
  constructor(level = 'info') {
    this.levels = ['debug', 'info', 'warn', 'error'];
    this.level = level;
  }

  log(level, message, context = {}) {
    if (this.levels.indexOf(level) >= this.levels.indexOf(this.level)) {
      const timestamp = new Date().toISOString();
      console[level](`[${timestamp}] [${level.toUpperCase()}] ${message}`, context);
    }
  }

  debug(msg, ctx) { this.log('debug', msg, ctx); }
  info(msg, ctx) { this.log('info', msg, ctx); }
  warn(msg, ctx) { this.log('warn', msg, ctx); }
  error(msg, ctx) { this.log('error', msg, ctx); }
}

// ------------------ Async Retry ------------------
async function retryAsync(fn, retries = 3, delay = 500) {
  let attempt = 0;
  while (attempt < retries) {
    try {
      return await fn();
    } catch (err) {
      attempt++;
      if (attempt >= retries) throw err;
      await new Promise(res => setTimeout(res, delay * Math.pow(2, attempt - 1)));
    }
  }
  throw new Error('retryAsync failed unexpectedly');
}

// ------------------ Deep Object Utilities ------------------
const DeepUtils = {
  get(obj, path, defaultVal) {
    return path.split('.').reduce((acc, key) => acc?.[key] ?? defaultVal, obj);
  },
  set(obj, path, value) {
    const keys = path.split('.');
    let temp = obj;
    keys.forEach((key, i) => {
      if (i === keys.length - 1) temp[key] = value;
      else temp[key] = temp[key] || {};
      temp = temp[key];
    });
  },
  clone(obj) { return JSON.parse(JSON.stringify(obj)); }
};

// ------------------ Async Queue ------------------
class AsyncQueue {
  constructor(concurrency = 2) {
    this.concurrency = concurrency;
    this.queue = [];
    this.running = 0;
  }

  push(task) {
    return new Promise((resolve, reject) => {
      this.queue.push({ task, resolve, reject });
      this.next();
    });
  }

  next() {
    if (this.running >= this.concurrency || this.queue.length === 0) return;
    const { task, resolve, reject } = this.queue.shift();
    this.running++;
    task().then(resolve).catch(reject).finally(() => {
      this.running--;
      this.next();
    });
  }
}

// ------------------ Schema Validator ------------------
function validate(obj, schema) {
  for (const key in schema) {
    const type = schema[key];
    if (typeof obj[key] !== type) throw new Error(`Expected ${key} to be ${type}`);
  }
  return true;
}

// ------------------ Memoization ------------------
function memoize(fn) {
  const cache = new Map();
  return (...args) => {
    const key = JSON.stringify(args);
    if (cache.has(key)) return cache.get(key);
    const result = fn(...args);
    cache.set(key, result);
    return result;
  };
}

// ------------------ Random Utilities ------------------
const RandomUtils = {
  choice: arr => arr[Math.floor(Math.random() * arr.length)],
  shuffle: arr => [...arr].sort(() => Math.random() - 0.5),
  sample: (arr, n) => RandomUtils.shuffle([...arr]).slice(0, n)
};

// ------------------ Time Profiler ------------------
function profile(fn, label = 'Function') {
  const start = performance.now();
  const result = fn();
  const end = performance.now();
  console.log(`${label} executed in ${(end - start).toFixed(2)}ms`);
  return result;
}

// ------------------ Exports ------------------
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    SmartLogger,
    retryAsync,
    DeepUtils,
    AsyncQueue,
    validate,
    memoize,
    RandomUtils,
    profile
  };
} else {
  window.DevUtils = {
    SmartLogger,
    retryAsync,
    DeepUtils,
    AsyncQueue,
    validate,
    memoize,
    RandomUtils,
    profile
  };
}
